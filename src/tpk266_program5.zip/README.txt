FIRSTNAME : Tyler;
LASTNAME : Kemme;
UTEID :  tpk266;
CSACCOUNT : tpkemme;
EMAIL : tpkemme@gmail.com

My algorithm starts by adding usernames,first names, and last names to the list of words of possible passwords for
each user.  After that, it checks each of those words against the actual encrypted password with the salt.  As long
as there are still some users with uncracked passwords, the program mangles all the words in the word list and adds 
them to another arraylist.  I make sure not to test all the words from the original wordlist again to save time. Finally,
if there are still users with uncracked passwords, the mangledWords list is mangled once more and these words are used to 
crack the password again.

First passwd file
=================
Here are the users with uncracked passwords:
This user's password is secure: caleb
This user's password is secure: nathan
This user's password is secure: connor
This user's password is secure: rachel
This user's password is secure: dustin
This user's password is secure: paige

Second passwd file
=================
This user's password is secure: samantha
This user's password is secure: alexander
This user's password is secure: benjamin
This user's password is secure: victor
This user's password is secure: nathan
This user's password is secure: connor
This user's password is secure: rachel
This user's password is secure: dustin
This user's password is secure: maria
This user's password is secure: paige
 